import os
import asyncio
import traceback
from threading import Thread

import aiohttp
import discord
from discord.ext import commands
from flask import Flask

from core.axon import axon
from utils.Tools import *
from utils.config import *

import jishaku

os.environ["JISHAKU_NO_DM_TRACEBACK"] = "False"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

from dotenv import load_dotenv
load_dotenv()
TOKEN = os.getenv("TOKEN")

client = axon()

WEBHOOK_URL = os.getenv("LOG_WEBHOOK_URL", "")


@client.event
async def on_ready():
    await client.wait_until_ready()
    print("""
           \033[1;31m

 ▄████▄   ▒█████  ▓█████▄ ▓█████ ▒██   ██▒
▒██▀ ▀█  ▒██▒  ██▒▒██▀ ██▌▓█   ▀ ▒▒ █ █ ▒░
▒▓█    ▄ ▒██░  ██▒░██   █▌▒███   ░░  █   ░
▒▓▓▄ ▄██▒▒██   ██░░▓█▄   ▌▒▓█  ▄  ░ █ █ ▒
▒ ▓███▀ ░░ ████▓▒░░▒████▓ ░▒████▒▒██▒ ▒██▒
░ ░▒ ▒  ░░ ▒░▒░▒░  ▒▒▓  ▒ ░░ ▒░ ░▒▒ ░ ░▓ ░
  ░  ▒     ░ ▒ ▒░  ░ ▒  ▒  ░ ░  ░░░   ░▒ ░
░        ░ ░ ░ ▒   ░ ░  ░    ░    ░    ░
░ ░          ░ ░     ░       ░  ░ ░    ░
░                  ░

           \033[0m
    """)
    print("Loaded & Online!")
    print(f"Logged in as: {client.user}")
    print(f"Connected to: {len(client.guilds)} guilds")
    print(f"Connected to: {len(client.users)} users")
    try:
        synced = await client.tree.sync()
        all_commands = list(client.commands)
        print(f"Synced {len(all_commands)} prefix commands and {len(synced)} slash commands")
    except Exception as e:
        print(e)


@client.event
async def on_command_completion(context: commands.Context) -> None:
    if not WEBHOOK_URL:
        return

    full_command_name = context.command.qualified_name
    executed_command = full_command_name.split("\n")[0]

    async with aiohttp.ClientSession() as session:
        webhook = discord.Webhook.from_url(WEBHOOK_URL, session=session)
        try:
            embed = discord.Embed(color=0x000000)
            avatar_url = (
                context.author.avatar.url
                if context.author.avatar
                else context.author.default_avatar.url
            )
            embed.set_author(
                name=f"Executed {executed_command} by {context.author}",
                icon_url=avatar_url,
            )
            embed.add_field(name="Command", value=executed_command, inline=False)
            embed.add_field(
                name="User",
                value=f"{context.author} | [{context.author.id}](https://discord.com/users/{context.author.id})",
                inline=False,
            )
            if context.guild:
                embed.add_field(
                    name="Guild",
                    value=f"{context.guild.name} | [{context.guild.id}](https://discord.com/guilds/{context.guild.id})",
                    inline=False,
                )
                embed.add_field(
                    name="Channel",
                    value=f"{context.channel.name} | [{context.channel.id}]",
                    inline=False,
                )
            embed.timestamp = discord.utils.utcnow()
            embed.set_footer(text="Axon Bot")
            await webhook.send(embed=embed)
        except Exception as e:
            print(f"Webhook log failed: {e}")


# ── Keep-alive server ─────────────────────────────────────────────────────────
app = Flask(__name__)


@app.route("/")
def home():
    return "Axon Development™ 2025"


def run():
    app.run(host="0.0.0.0", port=8080)


def keep_alive():
    Thread(target=run, daemon=True).start()


keep_alive()


# ── Entry point ───────────────────────────────────────────────────────────────
async def main():
    async with client:
        os.system("clear")
        await client.load_extension("jishaku")
        await client.start(TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
