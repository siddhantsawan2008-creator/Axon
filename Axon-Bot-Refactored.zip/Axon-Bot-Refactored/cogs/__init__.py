from __future__ import annotations
from core import axon
from colorama import Fore, Style, init

# ── Commands ──────────────────────────────────────────────────────────────────
from .commands.help import Help
from .commands.general import General
from .commands.extra import Extra
from .commands.owner import Owner, Badges
from .commands.owner2 import Global
from .commands.ignore import Ignore
from .commands.giveaway import Giveaway
from .commands.Embed import Embed
from .commands.steal import Steal
from .commands.ship import Ship
from .commands.timer import Timer
from .commands.blacklist import Blacklist
from .commands.block import Block
from .commands.nightmode import Nightmode
from .commands.autoresponder import AutoResponder
from .commands.customrole import Customrole
from .commands.autorole import AutoRole
from .commands.ticket import TicketSystem
from .commands.translate import TranslateCog
from .commands.autoreact import AutoReaction
from .commands.stats import Stats
from .commands.status import Status
from .commands.np import NoPrefix
from .commands.qr import QR
from .commands.vanityroles import VanityRoles
from .commands.reactionroles import ReactionRoles
from .commands.messages import Messages
from .commands.fastgreet import FastGreet
from .commands.slots import Slots
from .commands.blackjack import Blackjack
from .commands.notify import NotifCommands

# ── Events ────────────────────────────────────────────────────────────────────
from .events.autoblacklist import AutoBlacklist
from .events.Errors import Errors
from .events.on_guild import Guild
from .events.autorole import Autorole2
from .events.auto import Autorole
from .events.mention import Mention
from .events.react import React
from .events.autoreact import AutoReactListener

# ── Help panels (axon/) ───────────────────────────────────────────────────────
from .axon.extra import _extra
from .axon.general import _general
from .axon.ignore import _ignore
from .axon.server import _server
from .axon.giveaway import _giveaway
from .axon.ticket import _ticket
from .axon.vanity import _vanity


async def setup(bot: axon):
    cogs = [
        # Commands
        Help, General, Extra, Owner, Badges, Global, Ignore,
        Giveaway, Embed, Steal, Ship, Timer,
        Blacklist, Block, Nightmode, AutoResponder, Customrole, AutoRole,
        TicketSystem, TranslateCog, AutoReaction, Stats, Status, NoPrefix,
        QR, VanityRoles, ReactionRoles, Messages, FastGreet,
        Slots, Blackjack, NotifCommands,

        # Events
        AutoBlacklist, Guild, Errors, Autorole2, Autorole,
        Mention, React, AutoReactListener,

        # Help panels
        _extra, _general, _ignore, _server, _giveaway, _ticket, _vanity,
    ]

    for cog in cogs:
        await bot.add_cog(cog(bot))
        print(Fore.BLUE + Style.BRIGHT + f"Loaded cog: {cog.__name__}")

    print(Fore.GREEN + Style.BRIGHT + "All Axon Cogs loaded successfully.")
