from __future__ import annotations
from core import axon
from colorama import Fore, Style, init

# ── Commands ──────────────────────────────────────────────────────────────────
from .commands.help import Help
from .commands.general import General
from .commands.extra import Extra
from .commands.owner import Owner, Badges
from .commands.owner2 import Global
from .commands.ignore import Ignore
from .commands.giveaway import Giveaway
from .commands.Embed import Embed
from .commands.timer import Timer
from .commands.blacklist import Blacklist
from .commands.block import Block
from .commands.nightmode import Nightmode
from .commands.customrole import Customrole
from .commands.ticket import TicketSystem
from .commands.translate import TranslateCog
from .commands.stats import Stats
from .commands.np import NoPrefix
from .commands.qr import QR
from .commands.messages import Messages
from .commands.slots import Slots
from .commands.blackjack import Blackjack

# ── Events ────────────────────────────────────────────────────────────────────
from .events.autoblacklist import AutoBlacklist
from .events.Errors import Errors
from .events.on_guild import Guild
from .events.mention import Mention

# ── Help panels (axon/) ───────────────────────────────────────────────────────
from .axon.extra import _extra
from .axon.general import _general
from .axon.ignore import _ignore
from .axon.giveaway import _giveaway
from .axon.ticket import _ticket


async def setup(bot: axon):
    cogs = [
        # Commands
        Help, General, Extra, Owner, Badges, Global, Ignore,
        Giveaway, Embed, Timer, Blacklist, Block, Nightmode,
        Customrole, TicketSystem, TranslateCog, Stats, NoPrefix,
        QR, Messages, Slots, Blackjack,

        # Events
        AutoBlacklist, Guild, Errors, Mention,

        # Help panels
        _extra, _general, _ignore, _giveaway, _ticket,
    ]

    for cog in cogs:
        await bot.add_cog(cog(bot))
        print(Fore.BLUE + Style.BRIGHT + f"Loaded cog: {cog.__name__}")

    print(Fore.GREEN + Style.BRIGHT + "All Axon Cogs loaded successfully.")
